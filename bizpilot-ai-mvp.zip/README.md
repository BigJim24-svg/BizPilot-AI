# BizPilot AI — MVP

AI business copilot for small/medium businesses: dashboard, AI-scored leads,
an AI Copilot chat grounded in real business data, and daily recommendations.

## What's in this codebase

| Layer | Location | Status |
|---|---|---|
| Frontend prototype | `bizpilot-dashboard.jsx` (separate file) | Working, mock data |
| Database schema | `schema.sql` | Ready to run |
| Demo data | `seed.sql` | Ready to run |
| Backend API | `app/api/*` | Ready, needs real env vars |
| Lead scoring | `lib/scoring.ts` | Working, rule-based |
| CSV import mapping | `lib/csvMapping.ts` | Working |
| AI agents | `lib/ai/agents.ts` | Needs `ANTHROPIC_API_KEY` |
| Auth | Supabase Auth (via `lib/supabase.ts`) | Needs Supabase project |

## Setup (does not require writing code — copy/paste steps)

### 1. Database (Supabase)
1. Create a free project at supabase.com
2. Open the SQL Editor, paste the contents of `schema.sql`, run it
3. In Authentication > Users, manually add a user `demo@bizpilot.ai` and set a password
4. Copy that user's UUID, paste it into `seed.sql` where marked, then run `seed.sql`
5. Copy your Project URL, anon key, and service role key into `.env` (see `.env.example`)

### 2. AI (Anthropic)
1. Create a key at console.anthropic.com
2. Add it as `ANTHROPIC_API_KEY` in `.env`

### 3. Run locally
```
npm install
npm run dev
```
Visit `http://localhost:3000`, log in with the demo account.

### 4. Deploy (Vercel)
1. Push this code to a GitHub repo
2. Import the repo at vercel.com/new
3. Add the same environment variables from `.env` in Vercel's project settings
4. Deploy — Vercel gives you a live URL automatically

## Tenant isolation (security)

Every business-owned table (`customers`, `leads`, `sales`, `expenses`,
`ai_insights`) has Row Level Security enabled in `schema.sql`, AND every
API route independently resolves `business_id` from the caller's auth
token rather than trusting anything sent in the request. Two layers on
purpose — one bug in application code should never leak another
business's data.

## What's still missing before real customers

- Password reset / email verification flows (Supabase Auth provides these,
  just needs UI wired up)
- Stripe billing integration for the paid tiers
- CSV upload UI (the API is done — `app/api/csv-upload/route.ts` — needs
  a frontend page)
- Rate limiting on the AI Copilot endpoint (to control API cost per plan tier)
- Automated tests
