import Anthropic from "@anthropic-ai/sdk";

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
const MODEL = "claude-sonnet-4-6";

// -----------------------------------------------------------------
// Agent system (plan §2). Each agent gets ONLY the data slice it
// needs — never the whole database — then the Recommendation Agent
// synthesizes their findings into actionable insights.
// -----------------------------------------------------------------

interface BusinessSnapshot {
  revenue: { current: number; previous: number };
  expenses: { current: number; previous: number };
  leads: Array<{ name: string; score: number; reason: string; value: number }>;
  customers: Array<{ name: string; lifetimeValue: number; inactiveDays: number }>;
  topProducts: Array<{ name: string; revenue: number; growthPct: number }>;
}

async function callAgent(systemPrompt: string, userPrompt: string): Promise<string> {
  const response = await anthropic.messages.create({
    model: MODEL,
    max_tokens: 600,
    system: systemPrompt,
    messages: [{ role: "user", content: userPrompt }],
  });
  const block = response.content.find((b) => b.type === "text");
  return block && block.type === "text" ? block.text : "";
}

export async function runFinancialAgent(snapshot: BusinessSnapshot) {
  const revenueChange = pctChange(snapshot.revenue.current, snapshot.revenue.previous);
  return callAgent(
    "You are BizPilot's Financial Intelligence Agent. You analyze revenue, expenses, and margins for a small business. Be concise, specific, and cite the numbers given. Never give tax, legal, or accounting advice — only business analysis.",
    `Revenue: $${snapshot.revenue.current} (${revenueChange}% vs last period). Expenses: $${snapshot.expenses.current} (previous: $${snapshot.expenses.previous}). Summarize the financial picture in 2-3 sentences.`
  );
}

export async function runSalesAgent(snapshot: BusinessSnapshot) {
  const topLeads = snapshot.leads.slice(0, 5)
    .map((l) => `${l.name} (score ${l.score}, $${l.value}, ${l.reason})`)
    .join("; ");
  return callAgent(
    "You are BizPilot's Sales Agent. You analyze leads and pipeline health for a small business and recommend who to contact first, based only on the data given.",
    `Top scored leads: ${topLeads}. Identify the 3 highest-priority actions in 2-3 sentences.`
  );
}

export async function runCustomerIntelligenceAgent(snapshot: BusinessSnapshot) {
  const atRisk = snapshot.customers.filter((c) => c.inactiveDays > 30);
  return callAgent(
    "You are BizPilot's Customer Intelligence Agent. You analyze customer behavior and churn risk for a small business.",
    `${atRisk.length} customers inactive 30+ days, combined lifetime value $${atRisk.reduce((s, c) => s + c.lifetimeValue, 0)}. Summarize churn risk and reactivation opportunity in 2-3 sentences.`
  );
}

// The Recommendation Agent combines the other agents' output into
// the actionable cards shown on the Recommendations view.
export async function runRecommendationAgent(snapshot: BusinessSnapshot) {
  const [financial, sales, customer] = await Promise.all([
    runFinancialAgent(snapshot),
    runSalesAgent(snapshot),
    runCustomerIntelligenceAgent(snapshot),
  ]);

  const synthesis = await callAgent(
    "You are BizPilot's Recommendation Agent. You receive findings from three specialist agents (financial, sales, customer intelligence) and turn them into 3-5 short, prioritized, actionable recommendations for a small business owner. Format each as: Title | one-sentence explanation | one concrete next action | estimated impact if stated in the source data. Do not invent numbers not present in the input.",
    `Financial Agent: ${financial}\n\nSales Agent: ${sales}\n\nCustomer Intelligence Agent: ${customer}`
  );

  return { financial, sales, customer, synthesis };
}

// Powers the "Ask BizPilot anything" chat — grounded in the same
// snapshot so answers reflect the account's real data, not generic advice.
export async function answerCopilotQuestion(question: string, snapshot: BusinessSnapshot) {
  return callAgent(
    "You are BizPilot AI, a business copilot. Answer the owner's question using ONLY the data snapshot provided. Be specific and cite numbers. If the data doesn't cover the question, say so plainly instead of guessing.",
    `Business data snapshot: ${JSON.stringify(snapshot)}\n\nQuestion: ${question}`
  );
}

function pctChange(current: number, previous: number): string {
  if (previous === 0) return "0";
  return (((current - previous) / previous) * 100).toFixed(1);
}
