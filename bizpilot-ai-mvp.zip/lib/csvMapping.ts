// Detects which uploaded CSV column maps to which BizPilot field,
// so onboarding doesn't force the user into a rigid template.

const FIELD_ALIASES: Record<string, string[]> = {
  name: ["name", "customer", "customer name", "full name", "client"],
  email: ["email", "e-mail", "email address"],
  phone: ["phone", "phone number", "mobile", "contact number"],
  company: ["company", "business", "organization"],
  amount: ["amount", "revenue", "value", "price", "total", "sale amount"],
  date: ["date", "sale date", "purchase date", "created at", "expense date"],
  category: ["category", "type", "expense type"],
  status: ["status", "stage"],
};

export interface ColumnMapping {
  [csvColumn: string]: string | null; // maps to a BizPilot field, or null if unmatched
}

export function detectMapping(headers: string[]): ColumnMapping {
  const mapping: ColumnMapping = {};
  for (const header of headers) {
    const normalized = header.trim().toLowerCase();
    let matched: string | null = null;
    for (const [field, aliases] of Object.entries(FIELD_ALIASES)) {
      if (aliases.includes(normalized)) {
        matched = field;
        break;
      }
    }
    mapping[header] = matched;
  }
  return mapping;
}

// Columns BizPilot couldn't confidently map — the onboarding UI
// should prompt the user to confirm these manually.
export function unmappedColumns(mapping: ColumnMapping): string[] {
  return Object.entries(mapping)
    .filter(([, field]) => field === null)
    .map(([column]) => column);
}
