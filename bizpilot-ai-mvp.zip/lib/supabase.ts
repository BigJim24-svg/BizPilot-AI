import { createClient } from "@supabase/supabase-js";

// Browser / client-side client — respects Row Level Security.
export const supabaseClient = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
);

// Server-side client — uses the service role key, so it BYPASSES RLS.
// Only use inside API routes, and ALWAYS manually filter by business_id.
// Never expose this client or the service role key to the browser.
export const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

// Helper every API route must use: resolves the caller's business_id
// from their session, so we never trust a business_id sent in a request body.
export async function getBusinessIdForRequest(accessToken: string): Promise<string | null> {
  const { data: { user }, error } = await supabaseClient.auth.getUser(accessToken);
  if (error || !user) return null;

  const { data: business } = await supabaseAdmin
    .from("businesses")
    .select("id")
    .eq("user_id", user.id)
    .limit(1)
    .single();

  return business?.id ?? null;
}
