// Rule-based lead scoring engine (see plan §7).
// AI explains the score — it never invents it — so results stay auditable.

export interface ScoringSignals {
  recentPurchase: boolean;      // purchase in last 14 days
  highPurchaseValue: boolean;   // lifetime value above business median
  emailOpened: boolean;         // opened most recent email
  proposalViewed: boolean;      // viewed a sent proposal
  recentInteraction: boolean;   // any touchpoint in last 7 days
  noResponseDays: number;       // days since last reply
  inactiveDays: number;         // days since last purchase/contact
}

const WEIGHTS = {
  recentPurchase: 20,
  highPurchaseValue: 20,
  emailOpened: 10,
  proposalViewed: 15,
  recentInteraction: 15,
  noResponsePenalty: -10, // applied once if noResponseDays > 5
  inactivePenalty: -20,   // applied once if inactiveDays > 60
};

export function scoreLead(signals: ScoringSignals): number {
  let score = 0;
  if (signals.recentPurchase) score += WEIGHTS.recentPurchase;
  if (signals.highPurchaseValue) score += WEIGHTS.highPurchaseValue;
  if (signals.emailOpened) score += WEIGHTS.emailOpened;
  if (signals.proposalViewed) score += WEIGHTS.proposalViewed;
  if (signals.recentInteraction) score += WEIGHTS.recentInteraction;
  if (signals.noResponseDays > 5) score += WEIGHTS.noResponsePenalty;
  if (signals.inactiveDays > 60) score += WEIGHTS.inactivePenalty;

  return Math.max(0, Math.min(100, score));
}

export function temperatureFromScore(score: number): "hot" | "warm" | "cold" {
  if (score >= 80) return "hot";
  if (score >= 50) return "warm";
  return "cold";
}

// Human-readable reason string, so the UI can show WHY a lead scored
// the way it did (never just a bare number).
export function explainScore(signals: ScoringSignals): string {
  const reasons: string[] = [];
  if (signals.proposalViewed) reasons.push("viewed proposal");
  if (signals.recentPurchase) reasons.push("purchased recently");
  if (signals.highPurchaseValue) reasons.push("high lifetime value");
  if (signals.emailOpened) reasons.push("opened last email");
  if (signals.inactiveDays > 60) reasons.push(`inactive ${signals.inactiveDays} days`);
  if (signals.noResponseDays > 5) reasons.push(`no response in ${signals.noResponseDays} days`);
  return reasons.length ? reasons.join(", ") : "limited recent signal";
}
