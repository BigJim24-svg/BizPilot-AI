import { NextRequest, NextResponse } from "next/server";
import { supabaseAdmin, getBusinessIdForRequest } from "@/lib/supabase";
import { answerCopilotQuestion, runRecommendationAgent } from "@/lib/ai/agents";
import { temperatureFromScore } from "@/lib/scoring";

// Builds the data snapshot each agent call is grounded in.
// Keeping this in one place means every agent sees consistent, real data —
// never numbers invented by the model.
async function buildSnapshot(businessId: string) {
  const [{ data: sales }, { data: expenses }, { data: leads }, { data: customers }] = await Promise.all([
    supabaseAdmin.from("sales").select("amount, product, sale_date").eq("business_id", businessId),
    supabaseAdmin.from("expenses").select("amount, expense_date").eq("business_id", businessId),
    supabaseAdmin.from("leads").select("score, value, customers(name)").eq("business_id", businessId).order("score", { ascending: false }).limit(10),
    supabaseAdmin.from("customers").select("name, lifetime_value, last_contact").eq("business_id", businessId),
  ]);

  const now = Date.now();
  const daysSince = (d: string | null) => d ? Math.floor((now - new Date(d).getTime()) / 86400000) : 999;

  return {
    revenue: { current: sumRecent(sales, "amount", 30), previous: sumRecent(sales, "amount", 30, 30) },
    expenses: { current: sumRecent(expenses, "amount", 30), previous: sumRecent(expenses, "amount", 30, 30) },
    leads: (leads ?? []).map((l: any) => ({
      name: l.customers?.name ?? "Unknown", score: l.score, value: l.value,
      reason: temperatureFromScore(l.score),
    })),
    customers: (customers ?? []).map((c: any) => ({
      name: c.name, lifetimeValue: c.lifetime_value, inactiveDays: daysSince(c.last_contact),
    })),
    topProducts: [], // populate once product-level sale tracking is added
  };
}

function sumRecent(rows: any[] | null, field: string, windowDays: number, offsetDays = 0): number {
  if (!rows) return 0;
  const now = Date.now();
  const start = now - (offsetDays + windowDays) * 86400000;
  const end = now - offsetDays * 86400000;
  return rows
    .filter((r) => {
      const t = new Date(r.sale_date ?? r.expense_date).getTime();
      return t >= start && t < end;
    })
    .reduce((s, r) => s + Number(r[field] ?? 0), 0);
}

// POST /api/ai/copilot — { question: string }
export async function POST(req: NextRequest) {
  const token = req.headers.get("authorization")?.replace("Bearer ", "") ?? "";
  const businessId = await getBusinessIdForRequest(token);
  if (!businessId) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { question } = await req.json();
  const snapshot = await buildSnapshot(businessId);
  const answer = await answerCopilotQuestion(question, snapshot as any);

  return NextResponse.json({ answer });
}

// GET /api/ai/copilot — generates today's Recommendations brief
export async function GET(req: NextRequest) {
  const token = req.headers.get("authorization")?.replace("Bearer ", "") ?? "";
  const businessId = await getBusinessIdForRequest(token);
  if (!businessId) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const snapshot = await buildSnapshot(businessId);
  const result = await runRecommendationAgent(snapshot as any);

  // Persist so the Recommendations view has history, not just today's call.
  await supabaseAdmin.from("ai_insights").insert({
    business_id: businessId,
    type: "synthesis",
    severity: "opportunity",
    title: "Daily business brief",
    description: result.synthesis,
    recommendation: result.synthesis,
  });

  return NextResponse.json(result);
}
