import { NextRequest, NextResponse } from "next/server";
import Papa from "papaparse";
import { supabaseAdmin, getBusinessIdForRequest } from "@/lib/supabase";
import { detectMapping } from "@/lib/csvMapping";

// POST /api/csv-upload
// Body: { csvText: string, targetTable: "customers" | "sales" | "expenses", confirmedMapping?: ColumnMapping }
// Step 1 (no confirmedMapping): returns detected column mapping for user confirmation.
// Step 2 (with confirmedMapping): inserts rows using the confirmed mapping.
export async function POST(req: NextRequest) {
  const token = req.headers.get("authorization")?.replace("Bearer ", "") ?? "";
  const businessId = await getBusinessIdForRequest(token);
  if (!businessId) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { csvText, targetTable, confirmedMapping } = await req.json();
  const parsed = Papa.parse(csvText, { header: true, skipEmptyLines: true });

  if (parsed.errors.length) {
    return NextResponse.json({ error: "Could not parse CSV", details: parsed.errors }, { status: 400 });
  }

  const headers = parsed.meta.fields ?? [];

  if (!confirmedMapping) {
    // Return the auto-detected mapping so the frontend can show a
    // confirmation step before anything touches the database.
    const mapping = detectMapping(headers);
    return NextResponse.json({ mapping, rowCount: parsed.data.length, preview: parsed.data.slice(0, 5) });
  }

  // Apply confirmed mapping and insert.
  const rows = (parsed.data as Record<string, string>[]).map((row) => {
    const mapped: Record<string, any> = { business_id: businessId };
    for (const [csvCol, field] of Object.entries(confirmedMapping)) {
      if (field) mapped[field as string] = row[csvCol];
    }
    return mapped;
  });

  const { error, count } = await supabaseAdmin
    .from(targetTable)
    .insert(rows, { count: "exact" });

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ inserted: count });
}
