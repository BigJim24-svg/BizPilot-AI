import { NextRequest, NextResponse } from "next/server";
import { supabaseAdmin, getBusinessIdForRequest } from "@/lib/supabase";
import { scoreLead, temperatureFromScore, explainScore } from "@/lib/scoring";

// GET /api/leads — list leads for the caller's business, ranked by score.
export async function GET(req: NextRequest) {
  const token = req.headers.get("authorization")?.replace("Bearer ", "") ?? "";
  const businessId = await getBusinessIdForRequest(token);
  if (!businessId) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { data, error } = await supabaseAdmin
    .from("leads")
    .select("*, customers(name, email)")
    .eq("business_id", businessId) // tenant isolation — never trust client-supplied business_id
    .order("score", { ascending: false });

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });

  const withTemp = data.map((l) => ({ ...l, temperature: temperatureFromScore(l.score) }));
  return NextResponse.json({ leads: withTemp });
}

// POST /api/leads — create/recompute a lead's score from signals.
export async function POST(req: NextRequest) {
  const token = req.headers.get("authorization")?.replace("Bearer ", "") ?? "";
  const businessId = await getBusinessIdForRequest(token);
  if (!businessId) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const body = await req.json();
  const { customerId, value, source, signals } = body;

  const score = scoreLead(signals);
  const reason = explainScore(signals);

  const { data, error } = await supabaseAdmin
    .from("leads")
    .insert({
      business_id: businessId,
      customer_id: customerId,
      value,
      source,
      score,
      probability: score, // simple v1 mapping; refine with historical conversion data later
      last_interaction: new Date().toISOString(),
    })
    .select()
    .single();

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ lead: { ...data, temperature: temperatureFromScore(score), reason } });
}
