-- =========================================================
-- Demo account — run AFTER schema.sql.
-- Gives you a working login with realistic data to show
-- prospects, without needing real customer data yet.
-- Demo login: demo@bizpilot.ai / (set password via Supabase Auth UI)
-- =========================================================

-- 1. Create the demo user in Supabase Auth first (Dashboard > Authentication
--    > Add User, email: demo@bizpilot.ai), then paste that user's UUID below.
-- Replace 'PASTE_AUTH_USER_UUID_HERE' before running.

insert into users (id, name, email, password_hash, subscription)
values ('PASTE_AUTH_USER_UUID_HERE', 'Jimmy Rivera', 'demo@bizpilot.ai', 'managed_by_supabase_auth', 'business');

insert into businesses (id, user_id, business_name, industry, currency, country, health_score)
values ('11111111-1111-1111-1111-111111111111', 'PASTE_AUTH_USER_UUID_HERE', 'Jimmy''s Store', 'E-commerce', 'USD', 'US', 62);

-- Customers
insert into customers (business_id, name, email, status, lead_score, last_contact, lifetime_value) values
('11111111-1111-1111-1111-111111111111', 'John Smith', 'john@example.com', 'active', 94, now() - interval '3 days', 2400),
('11111111-1111-1111-1111-111111111111', 'Sarah Nolan', 'sarah@example.com', 'active', 89, now() - interval '45 days', 1850),
('11111111-1111-1111-1111-111111111111', 'Michael Ortiz', 'michael@example.com', 'active', 83, now() - interval '1 day', 3100),
('11111111-1111-1111-1111-111111111111', 'Amina Yusuf', 'amina@example.com', 'active', 71, now() - interval '6 days', 980),
('11111111-1111-1111-1111-111111111111', 'David Kim', 'david@example.com', 'inactive', 58, now() - interval '31 days', 1200),
('11111111-1111-1111-1111-111111111111', 'Grace Liu', 'grace@example.com', 'inactive', 34, now() - interval '60 days', 420);

-- Sales — last ~6 months, enough for the revenue trend chart
insert into sales (business_id, amount, product, sale_date) values
('11111111-1111-1111-1111-111111111111', 18200, 'Product A', current_date - interval '5 months'),
('11111111-1111-1111-1111-111111111111', 19800, 'Product A', current_date - interval '4 months'),
('11111111-1111-1111-1111-111111111111', 21400, 'Product B', current_date - interval '3 months'),
('11111111-1111-1111-1111-111111111111', 20100, 'Product A', current_date - interval '2 months'),
('11111111-1111-1111-1111-111111111111', 23600, 'Product C', current_date - interval '1 month'),
('11111111-1111-1111-1111-111111111111', 19300, 'Product A', current_date);

-- Expenses
insert into expenses (business_id, category, amount, expense_date, description) values
('11111111-1111-1111-1111-111111111111', 'Marketing', 3200, current_date - interval '10 days', 'Paid ads'),
('11111111-1111-1111-1111-111111111111', 'Inventory', 5400, current_date - interval '20 days', 'Restock Product A'),
('11111111-1111-1111-1111-111111111111', 'Software', 340, current_date - interval '3 days', 'SaaS subscriptions');

-- Leads (linked to the customers above)
insert into leads (business_id, customer_id, source, stage, value, score, status, last_interaction)
select '11111111-1111-1111-1111-111111111111', id, 'csv_import', 'proposal', lifetime_value, lead_score, 'open', last_contact
from customers where business_id = '11111111-1111-1111-1111-111111111111';
