-- =========================================================
-- BizPilot AI — Core Postgres Schema
-- Tenant isolation model: every business-owned row carries
-- business_id, and every query MUST filter on it (see RLS
-- policies at the bottom, and lib/db.ts for the app-side rule).
-- =========================================================

create extension if not exists "uuid-ossp";

-- ---------- Users ----------
create table users (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  email text not null unique,
  password_hash text not null,
  subscription text not null default 'free', -- free | starter | business | pro
  created_at timestamptz not null default now()
);

-- ---------- Businesses ----------
-- A user can own more than one business account.
create table businesses (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references users(id) on delete cascade,
  business_name text not null,
  industry text not null,
  currency text not null default 'USD',
  country text,
  timezone text default 'UTC',
  health_score int default 50 check (health_score between 0 and 100),
  created_at timestamptz not null default now()
);

create index idx_businesses_user on businesses(user_id);

-- ---------- Customers ----------
create table customers (
  id uuid primary key default uuid_generate_v4(),
  business_id uuid not null references businesses(id) on delete cascade,
  name text not null,
  email text,
  phone text,
  company text,
  status text not null default 'active', -- active | inactive | churned
  lead_score int default 0 check (lead_score between 0 and 100),
  last_contact timestamptz,
  lifetime_value numeric(12,2) default 0,
  created_at timestamptz not null default now()
);

create index idx_customers_business on customers(business_id);
create index idx_customers_score on customers(business_id, lead_score desc);

-- ---------- Leads ----------
create table leads (
  id uuid primary key default uuid_generate_v4(),
  business_id uuid not null references businesses(id) on delete cascade,
  customer_id uuid references customers(id) on delete set null,
  source text, -- csv_import | manual | api | shopify | ...
  stage text not null default 'new', -- new | contacted | proposal | won | lost
  value numeric(12,2) default 0,
  probability numeric(5,2) default 0, -- 0-100, derived from score
  score int default 0 check (score between 0 and 100),
  status text not null default 'open', -- open | closed
  last_interaction timestamptz,
  created_at timestamptz not null default now()
);

create index idx_leads_business on leads(business_id);
create index idx_leads_score on leads(business_id, score desc);

-- ---------- Sales ----------
create table sales (
  id uuid primary key default uuid_generate_v4(),
  business_id uuid not null references businesses(id) on delete cascade,
  customer_id uuid references customers(id) on delete set null,
  amount numeric(12,2) not null,
  product text,
  sale_date date not null default current_date,
  status text not null default 'completed', -- completed | refunded | pending
  created_at timestamptz not null default now()
);

create index idx_sales_business_date on sales(business_id, sale_date desc);

-- ---------- Expenses ----------
create table expenses (
  id uuid primary key default uuid_generate_v4(),
  business_id uuid not null references businesses(id) on delete cascade,
  category text not null,
  amount numeric(12,2) not null,
  expense_date date not null default current_date,
  description text,
  created_at timestamptz not null default now()
);

create index idx_expenses_business_date on expenses(business_id, expense_date desc);

-- ---------- AI Insights ----------
-- Output of the Recommendation Agent, shown on the
-- Recommendations / daily-brief view.
create table ai_insights (
  id uuid primary key default uuid_generate_v4(),
  business_id uuid not null references businesses(id) on delete cascade,
  type text not null, -- revenue | leads | customers | expenses | product
  severity text not null default 'opportunity', -- urgent | opportunity
  title text not null,
  description text not null,
  recommendation text not null,
  estimated_impact text,
  dismissed boolean default false,
  created_at timestamptz not null default now()
);

create index idx_insights_business on ai_insights(business_id, created_at desc);

-- =========================================================
-- Row Level Security — belt-and-suspenders tenant isolation.
-- Even if application code forgets a business_id filter, the
-- database refuses to return another tenant's rows.
-- Requires setting `app.current_business_id` per request
-- (see lib/db.ts) or adapting to your auth provider's JWT claims.
-- =========================================================

alter table customers enable row level security;
alter table leads enable row level security;
alter table sales enable row level security;
alter table expenses enable row level security;
alter table ai_insights enable row level security;

create policy tenant_isolation_customers on customers
  using (business_id::text = current_setting('app.current_business_id', true));
create policy tenant_isolation_leads on leads
  using (business_id::text = current_setting('app.current_business_id', true));
create policy tenant_isolation_sales on sales
  using (business_id::text = current_setting('app.current_business_id', true));
create policy tenant_isolation_expenses on expenses
  using (business_id::text = current_setting('app.current_business_id', true));
create policy tenant_isolation_insights on ai_insights
  using (business_id::text = current_setting('app.current_business_id', true));
