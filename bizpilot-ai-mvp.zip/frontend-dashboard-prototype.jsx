import React, { useState, useMemo } from "react";
import {
  LayoutGrid, Users, Target, TrendingUp, Sparkles, Bell,
  ArrowUpRight, ArrowDownRight, Send, ChevronRight, Flame,
  CircleDot, Clock, Wallet, AlertTriangle, CheckCircle2
} from "lucide-react";
import {
  LineChart, Line, XAxis, YAxis, ResponsiveContainer, Tooltip,
} from "recharts";

/* ---------------------------------------------------------
   BizPilot AI — MVP Prototype
   Dark "cockpit for founders" theme: near-black blue base,
   teal for AI/clarity, rose for urgency, green for growth.
--------------------------------------------------------- */

const FONT_LINK = "https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;500;600&family=Space+Grotesk:wght@500;600;700&display=swap";

const revenueTrend = [
  { m: "Mar", v: 18200 }, { m: "Apr", v: 19800 }, { m: "May", v: 21400 },
  { m: "Jun", v: 20100 }, { m: "Jul", v: 23600 }, { m: "Aug", v: 19300 },
];

const metrics = [
  { label: "Revenue (MTD)", value: "$19,300", delta: -18, deltaLabel: "vs last month", icon: Wallet },
  { label: "Active Leads", value: "142", delta: 6, deltaLabel: "vs last month", icon: Target },
  { label: "Conversion Rate", value: "11.4%", delta: -7, deltaLabel: "vs last month", icon: TrendingUp },
  { label: "Outstanding", value: "$4,120", delta: 12, deltaLabel: "unpaid invoices", icon: Clock },
];

const leads = [
  { id: 1, name: "John Smith", score: 94, temp: "hot", value: "$2,400", reason: "Viewed proposal twice, no reply in 3 days", last: "3 days ago" },
  { id: 2, name: "Sarah Nolan", score: 89, temp: "hot", value: "$1,850", reason: "High historical value, purchase gap 45 days", last: "45 days ago" },
  { id: 3, name: "Michael Ortiz", score: 83, temp: "hot", value: "$3,100", reason: "Opened last 2 emails, proposal pending", last: "1 day ago" },
  { id: 4, name: "Amina Yusuf", score: 71, temp: "warm", value: "$980", reason: "Recent interaction, no purchase yet", last: "6 days ago" },
  { id: 5, name: "David Kim", score: 58, temp: "warm", value: "$1,200", reason: "Inactive 30+ days, previously engaged", last: "31 days ago" },
  { id: 6, name: "Grace Liu", score: 34, temp: "cold", value: "$420", reason: "No response after 2 follow-ups", last: "60 days ago" },
];

const recommendations = [
  { severity: "urgent", title: "Revenue dropped 18% this month", body: "Returning-customer purchases fell sharply. 23 high-value customers have gone quiet.", action: "Contact 23 inactive high-value customers", impact: "$4,200 est. opportunity" },
  { severity: "urgent", title: "14 high-value leads haven't been contacted", body: "These leads scored above 80 but have had no outreach in 5+ days.", action: "Review and message top 14 leads", impact: "$18,600 pipeline at risk" },
  { severity: "opportunity", title: "Product A demand is rising", body: "Orders for Product A are up 34% week over week — inventory and staffing may need to catch up.", action: "Check Product A stock levels", impact: "Growth opportunity" },
  { severity: "opportunity", title: "Fridays generate your highest revenue", body: "Average Friday revenue is 40% above your weekly mean.", action: "Consider a Friday promotion", impact: "Pattern worth testing" },
];

const suggestedQuestions = [
  "Why did my sales decrease this month?",
  "Which customers should I contact today?",
  "What is my most profitable product?",
];

const copilotAnswers = {
  "Why did my sales decrease this month?":
    "Revenue is down 18% vs last month, driven mainly by returning customers: 23 previously active customers made no purchase in the last 30 days, together worth an estimated $4,200 in lost repeat revenue. New customer sales are flat, not declining — this is a retention issue, not an acquisition one. Contacting your highest-value inactive customers first is the fastest lever back to growth.",
  "Which customers should I contact today?":
    "Three leads stand out: John Smith (score 94) viewed your proposal twice and has gone quiet for 3 days — reply while it's fresh. Sarah Nolan (89) hasn't purchased in 45 days despite strong lifetime value. Michael Ortiz (83) has opened your last two emails, a live signal worth acting on now. I'd work these in that order.",
  "What is my most profitable product?":
    "Product A currently leads on margin and is trending up 34% week over week in order volume, ahead of Products B and C. It's also your highest repeat-purchase item, which makes it worth featuring in this week's outreach and any promotion.",
};

const nav = [
  { id: "dashboard", label: "Dashboard", icon: LayoutGrid },
  { id: "leads", label: "Leads", icon: Users },
  { id: "copilot", label: "AI Copilot", icon: Sparkles },
  { id: "recommendations", label: "Recommendations", icon: Bell },
];

function TempBadge({ temp }) {
  const map = {
    hot: { bg: "rgba(244,63,94,0.14)", fg: "#FB7185", label: "Hot" },
    warm: { bg: "rgba(94,234,212,0.12)", fg: "#5EEAD4", label: "Warm" },
    cold: { bg: "rgba(154,161,176,0.12)", fg: "#9AA1B0", label: "Cold" },
  };
  const s = map[temp];
  return (
    <span style={{ background: s.bg, color: s.fg }} className="text-xs font-medium px-2 py-1 rounded-md">
      {s.label}
    </span>
  );
}

function MetricCard({ m }) {
  const Icon = m.icon;
  const positive = m.delta >= 0;
  return (
    <div className="rounded-xl p-5 flex flex-col gap-3" style={{ background: "#171B24", border: "1px solid #262B36" }}>
      <div className="flex items-center justify-between">
        <span className="text-sm" style={{ color: "#9AA1B0" }}>{m.label}</span>
        <Icon size={16} style={{ color: "#5EEAD4" }} strokeWidth={1.75} />
      </div>
      <div style={{ fontFamily: "'Space Grotesk', sans-serif" }} className="text-2xl font-semibold" >{m.value}</div>
      <div className="flex items-center gap-1 text-xs">
        {positive
          ? <ArrowUpRight size={13} style={{ color: "#34D399" }} />
          : <ArrowDownRight size={13} style={{ color: "#FB7185" }} />}
        <span style={{ color: positive ? "#34D399" : "#FB7185" }}>{Math.abs(m.delta)}%</span>
        <span style={{ color: "#6B7280" }}>{m.deltaLabel}</span>
      </div>
    </div>
  );
}

function HealthScore() {
  const score = 62;
  const circumference = 2 * Math.PI * 42;
  const offset = circumference * (1 - score / 100);
  return (
    <div className="rounded-xl p-5 flex items-center gap-5" style={{ background: "#171B24", border: "1px solid #262B36" }}>
      <svg width="100" height="100" viewBox="0 0 100 100">
        <circle cx="50" cy="50" r="42" fill="none" stroke="#262B36" strokeWidth="8" />
        <circle
          cx="50" cy="50" r="42" fill="none" stroke="#F2A93B" strokeWidth="8"
          strokeDasharray={circumference} strokeDashoffset={offset}
          strokeLinecap="round" transform="rotate(-90 50 50)"
        />
        <text x="50" y="55" textAnchor="middle" fontSize="22" fontWeight="600" fill="#EDEFF3" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>{score}</text>
      </svg>
      <div className="flex flex-col gap-1">
        <span className="text-sm" style={{ color: "#9AA1B0" }}>Business Health</span>
        <span className="font-medium" style={{ color: "#F2A93B" }}>Needs attention</span>
        <span className="text-xs" style={{ color: "#6B7280" }}>Sales growth and conversion pulled the score down this month</span>
      </div>
    </div>
  );
}

function DashboardView() {
  return (
    <div className="flex flex-col gap-6">
      <div className="grid grid-cols-4 gap-4">
        {metrics.map((m) => <MetricCard key={m.label} m={m} />)}
      </div>
      <div className="grid grid-cols-3 gap-4">
        <div className="col-span-2 rounded-xl p-5" style={{ background: "#171B24", border: "1px solid #262B36" }}>
          <div className="flex items-center justify-between mb-4">
            <span className="text-sm font-medium">Revenue, last 6 months</span>
            <span className="text-xs" style={{ color: "#6B7280" }}>USD</span>
          </div>
          <ResponsiveContainer width="100%" height={180}>
            <LineChart data={revenueTrend}>
              <XAxis dataKey="m" stroke="#6B7280" fontSize={12} tickLine={false} axisLine={false} />
              <YAxis hide />
              <Tooltip
                contentStyle={{ background: "#1F2430", border: "1px solid #262B36", borderRadius: 8, fontSize: 12 }}
                labelStyle={{ color: "#9AA1B0" }}
                formatter={(v) => [`$${v.toLocaleString()}`, "Revenue"]}
              />
              <Line type="monotone" dataKey="v" stroke="#5EEAD4" strokeWidth={2.5} dot={{ r: 3, fill: "#5EEAD4" }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
        <HealthScore />
      </div>
      <div className="rounded-xl p-5" style={{ background: "#171B24", border: "1px solid #262B36" }}>
        <div className="flex items-center justify-between mb-4">
          <span className="text-sm font-medium">Today's priority leads</span>
          <span className="text-xs" style={{ color: "#5EEAD4" }}>3 need action</span>
        </div>
        <div className="flex flex-col divide-y" style={{ borderColor: "#262B36" }}>
          {leads.slice(0, 3).map((l) => (
            <div key={l.id} className="flex items-center justify-between py-3" style={{ borderColor: "#262B36" }}>
              <div className="flex items-center gap-3">
                <span style={{ fontFamily: "'Space Grotesk', sans-serif", color: "#5EEAD4" }} className="text-sm font-semibold w-8">{l.score}</span>
                <div className="flex flex-col">
                  <span className="text-sm">{l.name}</span>
                  <span className="text-xs" style={{ color: "#6B7280" }}>{l.reason}</span>
                </div>
              </div>
              <TempBadge temp={l.temp} />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function LeadsView({ onGenerate }) {
  return (
    <div className="rounded-xl p-5" style={{ background: "#171B24", border: "1px solid #262B36" }}>
      <div className="flex items-center justify-between mb-5">
        <span className="text-sm font-medium">Leads, ranked by score</span>
        <span className="text-xs" style={{ color: "#6B7280" }}>{leads.length} total</span>
      </div>
      <div className="flex flex-col gap-3">
        {leads.map((l) => (
          <div key={l.id} className="flex items-center justify-between rounded-lg p-4" style={{ background: "#1B2028", border: "1px solid #232834" }}>
            <div className="flex items-center gap-4">
              <div className="flex flex-col items-center justify-center w-12 h-12 rounded-lg" style={{ background: "rgba(94,234,212,0.08)" }}>
                <span style={{ fontFamily: "'Space Grotesk', sans-serif", color: "#5EEAD4" }} className="text-sm font-semibold">{l.score}</span>
              </div>
              <div className="flex flex-col gap-1">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-medium">{l.name}</span>
                  <TempBadge temp={l.temp} />
                </div>
                <span className="text-xs" style={{ color: "#6B7280" }}>{l.reason} · last contact {l.last}</span>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <span style={{ fontFamily: "'Space Grotesk', sans-serif" }} className="text-sm">{l.value}</span>
              <button
                onClick={() => onGenerate(l)}
                className="text-xs font-medium px-3 py-2 rounded-md transition-colors"
                style={{ background: "rgba(94,234,212,0.12)", color: "#5EEAD4" }}
              >
                Generate follow-up
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function FollowUpModal({ lead, onClose }) {
  if (!lead) return null;
  const msg = `Hi ${lead.name.split(" ")[0]}, following up on where things stand — ${lead.reason.toLowerCase()}. Happy to answer any questions or walk through next steps whenever works for you.`;
  return (
    <div className="fixed inset-0 flex items-center justify-center z-50" style={{ background: "rgba(6,8,12,0.6)" }} onClick={onClose}>
      <div onClick={(e) => e.stopPropagation()} className="rounded-xl p-6 w-[420px]" style={{ background: "#1B2028", border: "1px solid #262B36" }}>
        <div className="flex items-center gap-2 mb-3">
          <Sparkles size={15} style={{ color: "#5EEAD4" }} />
          <span className="text-sm font-medium">Follow-up for {lead.name}</span>
        </div>
        <p className="text-sm leading-relaxed p-3 rounded-lg mb-4" style={{ background: "#12151C", color: "#C7CBD4", border: "1px solid #232834" }}>
          {msg}
        </p>
        <div className="flex gap-2">
          <button className="flex-1 text-xs font-medium py-2 rounded-md" style={{ background: "#5EEAD4", color: "#0F1115" }} onClick={onClose}>Copy message</button>
          <button className="flex-1 text-xs font-medium py-2 rounded-md" style={{ background: "#232834", color: "#C7CBD4" }} onClick={onClose}>Close</button>
        </div>
      </div>
    </div>
  );
}

function CopilotView() {
  const [messages, setMessages] = useState([
    { role: "ai", text: "Ask me anything about your business — revenue, customers, leads, or products. I'll answer from your actual data." },
  ]);
  const [input, setInput] = useState("");

  const respond = (question) => {
    const answer = copilotAnswers[question] ||
      "I've reviewed your business data on this — connect a live account to get a fully data-grounded answer here. In the meantime, try one of the suggested questions to see a real example.";
    setMessages((m) => [...m, { role: "user", text: question }, { role: "ai", text: answer }]);
  };

  const handleSend = () => {
    if (!input.trim()) return;
    respond(input.trim());
    setInput("");
  };

  return (
    <div className="rounded-xl flex flex-col" style={{ background: "#171B24", border: "1px solid #262B36", height: 520 }}>
      <div className="flex-1 overflow-y-auto p-5 flex flex-col gap-4">
        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
            <div
              className="max-w-[75%] text-sm leading-relaxed px-4 py-3 rounded-xl"
              style={m.role === "user"
                ? { background: "#5EEAD4", color: "#0F1115" }
                : { background: "#1B2028", color: "#DCE0E6", border: "1px solid #232834" }}
            >
              {m.text}
            </div>
          </div>
        ))}
        {messages.length === 1 && (
          <div className="flex flex-col gap-2 mt-2">
            {suggestedQuestions.map((q) => (
              <button
                key={q}
                onClick={() => respond(q)}
                className="text-left text-sm px-4 py-3 rounded-lg transition-colors"
                style={{ background: "#1B2028", color: "#9AA1B0", border: "1px solid #232834" }}
              >
                {q}
              </button>
            ))}
          </div>
        )}
      </div>
      <div className="flex items-center gap-2 p-4" style={{ borderTop: "1px solid #262B36" }}>
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleSend()}
          placeholder="Ask BizPilot anything..."
          className="flex-1 text-sm px-4 py-3 rounded-lg outline-none"
          style={{ background: "#12151C", color: "#EDEFF3", border: "1px solid #262B36" }}
        />
        <button onClick={handleSend} className="p-3 rounded-lg" style={{ background: "#5EEAD4" }}>
          <Send size={16} style={{ color: "#0F1115" }} />
        </button>
      </div>
    </div>
  );
}

function RecommendationsView() {
  return (
    <div className="flex flex-col gap-4">
      <div className="rounded-xl p-5" style={{ background: "#171B24", border: "1px solid #262B36" }}>
        <div className="flex items-center gap-2 mb-1">
          <Sparkles size={15} style={{ color: "#5EEAD4" }} />
          <span className="text-sm font-medium">Your business brief — today</span>
        </div>
        <p className="text-xs" style={{ color: "#6B7280" }}>2 urgent issues · 2 opportunities</p>
      </div>
      {recommendations.map((r, i) => {
        const urgent = r.severity === "urgent";
        return (
          <div key={i} className="rounded-xl p-5 flex items-start gap-4" style={{ background: "#171B24", border: "1px solid #262B36" }}>
            <div className="mt-0.5">
              {urgent
                ? <AlertTriangle size={18} style={{ color: "#FB7185" }} />
                : <CheckCircle2 size={18} style={{ color: "#34D399" }} />}
            </div>
            <div className="flex-1 flex flex-col gap-2">
              <span className="text-sm font-medium">{r.title}</span>
              <p className="text-sm leading-relaxed" style={{ color: "#9AA1B0" }}>{r.body}</p>
              <div className="flex items-center justify-between mt-1">
                <span className="text-xs px-2 py-1 rounded-md" style={{ background: urgent ? "rgba(244,63,94,0.1)" : "rgba(52,211,153,0.1)", color: urgent ? "#FB7185" : "#34D399" }}>
                  {r.impact}
                </span>
                <button className="text-xs font-medium flex items-center gap-1" style={{ color: "#5EEAD4" }}>
                  {r.action} <ChevronRight size={13} />
                </button>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}

export default function BizPilotApp() {
  const [view, setView] = useState("dashboard");
  const [activeLead, setActiveLead] = useState(null);

  const heading = useMemo(() => ({
    dashboard: "Good morning — here's where things stand",
    leads: "Leads, prioritized for you",
    copilot: "AI Copilot",
    recommendations: "Recommendations",
  }[view]), [view]);

  return (
    <div style={{ background: "#0F1115", color: "#EDEFF3", fontFamily: "'IBM Plex Sans', sans-serif", minHeight: "100vh" }} className="flex text-[15px]">
      <link rel="stylesheet" href={FONT_LINK} />

      <aside className="flex flex-col justify-between py-6 px-4" style={{ width: 220, borderRight: "1px solid #1D212B" }}>
        <div>
          <div className="flex items-center gap-2 px-2 mb-8">
            <div className="w-7 h-7 rounded-md flex items-center justify-center" style={{ background: "#5EEAD4" }}>
              <CircleDot size={15} style={{ color: "#0F1115" }} />
            </div>
            <span style={{ fontFamily: "'Space Grotesk', sans-serif" }} className="font-semibold text-sm">BizPilot AI</span>
          </div>
          <nav className="flex flex-col gap-1">
            {nav.map((n) => {
              const Icon = n.icon;
              const active = view === n.id;
              return (
                <button
                  key={n.id}
                  onClick={() => setView(n.id)}
                  className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-colors text-left"
                  style={{
                    background: active ? "rgba(94,234,212,0.1)" : "transparent",
                    color: active ? "#5EEAD4" : "#9AA1B0",
                  }}
                >
                  <Icon size={16} strokeWidth={1.75} />
                  {n.label}
                </button>
              );
            })}
          </nav>
        </div>
        <div className="flex items-center gap-2 px-2">
          <div className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-medium" style={{ background: "#232834", color: "#C7CBD4" }}>JM</div>
          <div className="flex flex-col leading-tight">
            <span className="text-xs" style={{ color: "#DCE0E6" }}>Jimmy's Store</span>
            <span className="text-[11px]" style={{ color: "#6B7280" }}>Free plan</span>
          </div>
        </div>
      </aside>

      <main className="flex-1 p-8 max-w-[1040px]">
        <div className="mb-6">
          <h1 style={{ fontFamily: "'Space Grotesk', sans-serif" }} className="text-xl font-semibold">{heading}</h1>
        </div>
        {view === "dashboard" && <DashboardView />}
        {view === "leads" && <LeadsView onGenerate={setActiveLead} />}
        {view === "copilot" && <CopilotView />}
        {view === "recommendations" && <RecommendationsView />}
      </main>

      <FollowUpModal lead={activeLead} onClose={() => setActiveLead(null)} />
    </div>
  );
}
